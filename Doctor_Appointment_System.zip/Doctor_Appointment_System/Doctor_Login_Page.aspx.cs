﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Doctor_Appointment_System
{
    public partial class Doctor_Login_Page : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            con.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\chauh\Documents\Doctor_Appintment_System.mdf;Integrated Security=True;Connect Timeout=30";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home_Page.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand sd = new SqlCommand("select count(*) from Doctor_List where DoctorID = '" + TextBox1.Text + "' and Password = '" + TextBox2.Text + "'", con);
            int temp = Convert.ToInt32(sd.ExecuteScalar().ToString());
            con.Close();
            if (temp == 1)
            {
                Response.Redirect("D_My_Appointment.aspx");
            }
            else
            {
                Label4.Text = "Incorrect Information";
            }
        }
    }
}