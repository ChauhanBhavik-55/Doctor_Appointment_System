﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Doctor_Appointment_System
{
    public partial class Book_Appiontment : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            con.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\chauh\Documents\Doctor_Appintment_System.mdf;Integrated Security=True;Connect Timeout=30";
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            TextBox2.Text = Calendar1.SelectedDate.ToLongDateString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand save = new SqlCommand("insert into Book_Appointment(BookingID,Category,Doctor,Date,Time,Status)values('" + TextBox1.Text + "', '" + DropDownList1.Text + "', '" + DropDownList2.Text + "', '" + TextBox2.Text + "','" + DropDownList3.Text + "','" + DropDownList4.Text + "')", con);
            save.ExecuteNonQuery();
            con.Close();
        }
    }
}