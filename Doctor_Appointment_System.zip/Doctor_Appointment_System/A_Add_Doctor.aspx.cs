﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Doctor_Appointment_System
{
    public partial class A_Add_Doctor : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            con.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\chauh\Documents\Doctor_Appintment_System.mdf;Integrated Security=True;Connect Timeout=30";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("A_Add_Doctor.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand save = new SqlCommand("insert into Doctor_List(DoctorID,Name,Address,MobileNo,Email,Category,Password)values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" +DropDownList1.Text + "','"+TextBox6.Text+"')", con);
            save.ExecuteNonQuery();
            con.Close();
            Label8.Text = "Added Sucessfully";
        }
    }
}