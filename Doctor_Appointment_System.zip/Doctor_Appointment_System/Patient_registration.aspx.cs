﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Doctor_Appointment_System
{
    public partial class Patient_registration : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            con.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\chauh\Documents\Doctor_Appintment_System.mdf;Integrated Security=True;Connect Timeout=30";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand save = new SqlCommand("insert into Patient_Registration(PatientID,Name,Address,MobileNo,Email,Password)values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "')", con);
            save.ExecuteNonQuery();
            con.Close();
            Response.Redirect("Patient_Login_Page.aspx");
        }
    }
}