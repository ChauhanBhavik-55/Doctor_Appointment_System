﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Doctor_Appointment_System
{
    public partial class A_View_Appointment : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            con.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\chauh\Documents\Doctor_Appintment_System.mdf;Integrated Security=True;Connect Timeout=30";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Book_Appointment where BookingID =" + TextBox1.Text, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                TextBox2.Text = (dr["Status"].ToString());
            }
            con.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand save = new SqlCommand("Update Book_Appointment set Status='" + DropDownList1.SelectedItem.Text + "' where BookingID='" + TextBox1.Text + "'", con);
            save.ExecuteNonQuery();
            con.Close();
        }
    }
}