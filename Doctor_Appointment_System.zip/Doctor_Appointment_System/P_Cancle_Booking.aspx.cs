﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Doctor_Appointment_System
{
    public partial class P_Cancle_Booking : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            con.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\chauh\Documents\Doctor_Appintment_System.mdf;Integrated Security=True;Connect Timeout=30";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand save = new SqlCommand("delete from Book_Appointment where BookingID ='" + TextBox1.Text + "'", con);
            save.ExecuteNonQuery();
            Label3.Text = "Booking Cancle sucessfully";
            con.Close();
        }
    }
}